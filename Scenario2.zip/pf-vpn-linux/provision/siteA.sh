#!/bin/bash
echo "[siteA] Configuration du client..."

DEBIAN_FRONTEND=noninteractive apt install -y iptables-persistent


sed -i 's/ospfd=no/ospfd=yes/' /etc/frr/daemons
systemctl enable frr && systemctl restart frr

cp /vagrant/frr/frr.conf.siteA /etc/frr/frr.conf
chown frr:frr /etc/frr/frr.conf

echo "[siteA] Configuration terminée."
