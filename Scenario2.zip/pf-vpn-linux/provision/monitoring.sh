#!/bin/bash
echo "[monitoring] Installation de Prometheus et Grafana..."

apt update && apt install -y prometheus grafana net-tools

systemctl enable prometheus
systemctl start prometheus

systemctl enable grafana-server
systemctl start grafana-server

echo "[monitoring] Services Prometheus et Grafana lancés."
