#!/bin/bash
echo "[siteB] Configuration du peer distant..."

apt update && apt install -y frr wireguard net-tools

sed -i 's/ospfd=no/ospfd=yes/' /etc/frr/daemons
systemctl enable frr && systemctl restart frr

cp /vagrant/frr/frr.conf.siteB /etc/frr/frr.conf
chown frr:frr /etc/frr/frr.conf

echo "[siteB] Configuration terminée."
