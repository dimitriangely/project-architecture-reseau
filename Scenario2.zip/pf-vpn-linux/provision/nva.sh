#!/bin/bash
echo "[NVA] Configuration du routeur..."

apt update && apt install -y frr wireguard iptables-persistent net-tools

echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
sysctl -p

sed -i 's/ospfd=no/ospfd=yes/' /etc/frr/daemons
systemctl enable frr && systemctl restart frr

cp /vagrant/frr/frr.conf.nva /etc/frr/frr.conf
chown frr:frr /etc/frr/frr.conf

iptables -t nat -A POSTROUTING -o enp0s9 -j MASQUERADE
netfilter-persistent save

echo "[NVA] Configuration terminée."
